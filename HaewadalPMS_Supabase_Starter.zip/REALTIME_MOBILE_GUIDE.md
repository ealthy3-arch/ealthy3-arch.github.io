# PMS 모바일 실시간 사용 가이드

## 1) 서버 실행
`haewadal_pms` 폴더에서 아래 명령을 실행하세요.

```powershell
cd C:\Users\mine8\Desktop\codex-pms\haewadal_pms
python realtime_server.py --host 0.0.0.0 --port 8787
```

실행 후 콘솔에 아래와 같은 주소가 표시됩니다.

- `Mobile URL: http://<PC_IP>:8787/mobile`

## 2) 다른 기기(모바일)에서 접속
- 모바일을 같은 Wi-Fi에 연결
- 브라우저에서 `http://<PC_IP>:8787/mobile` 접속

예시:
- `http://192.168.0.25:8787/mobile`

## 3) 실시간 반영 방식
- 모바일 화면은 1.5초 주기로 서버 버전을 확인합니다.
- DB가 변경되면 자동 새로고침되어 객실 상태가 반영됩니다.

## 4) 가능한 작업
- 객실 현황 조회
- 모바일 체크인
- 모바일 체크아웃
- 객실 상태 변경 (공실/청소중)

## 5) 보안 옵션 (선택)
쓰기 API를 잠그려면 API 키를 사용하세요.

```powershell
set HAEWADAL_API_KEY=원하는비밀키
python realtime_server.py --host 0.0.0.0 --port 8787
```

## 6) 방화벽
외부 기기 접속이 안 되면 Windows 방화벽에서 Python 또는 8787 포트를 허용하세요.

