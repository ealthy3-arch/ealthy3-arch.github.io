﻿[해와달 PMS Supabase 스타터 안내]

1) 이 스타터는 "여러 기기에서 같은 데이터 보기"를 위한 설정 도구입니다.
2) 먼저 setup.exe로 PMS 설치를 완료하세요.

실행 파일
- start_pms_with_supabase.bat
  : 기본 실행 (메인PC push 모드)
- start_pms_follower_with_supabase.bat
  : 보조PC 실행 (pull 자동반영 모드)
- start_supabase_sync.bat
  : 소스코드 기반 별도 동기화 감시 도구(고급용)

첫 실행 입력값
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY (Project API Keys의 secret/service_role 키)
- SUPABASE_SYNC_MODE (push 또는 pull)

중요
- Supabase Personal Access Token(sbp_...)은 여기서 사용하지 않습니다.
- publishable key(sb_publishable_...)도 쓰기 동기화에 사용할 수 없습니다.

권장 운영 방식 (안전)
- 메인PC 1대만 push 모드로 사용
- 친구 노트북/보조PC는 pull 모드로 사용
- 동시에 여러 PC를 push 모드로 쓰지 마세요(충돌 위험)

문제 해결
- 창이 바로 닫히면 cmd에서 실행해서 오류 메시지를 확인하세요.
- setup.exe를 먼저 설치했는지 확인하세요.
- SUPABASE_URL / SERVICE_ROLE_KEY 오타가 없는지 확인하세요.
