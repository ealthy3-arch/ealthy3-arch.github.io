# Supabase 연동 가이드 (다른 PC 공용 DB)

## 목적
- 기존 PC 프로그램은 그대로 사용
- 로컬 SQLite 데이터를 Supabase로 동기화
- 다른 PC/모바일에서도 같은 데이터 조회/복구 가능

## 1) Supabase 준비
1. Supabase 프로젝트 생성
2. SQL Editor에서 아래 파일 실행
   - `C:\Users\mine8\Desktop\codex-pms\haewadal_pms\supabase_schema.sql`
3. `Project URL` 확인
4. `service_role` 키 확인 (공개 금지)

## 2) 환경변수 설정 (메인 PC)
```powershell
set SUPABASE_URL=https://YOUR_PROJECT.supabase.co
set SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
```

필요 시 DB 경로 직접 지정:
```powershell
set HAEWADAL_DB_PATH=C:\Users\mine8\AppData\Local\HaewadalPMS\haewadal_pms.db
```

## 3) 1회 업로드 (초기 동기화)
```powershell
cd C:\Users\mine8\Desktop\codex-pms\haewadal_pms
python supabase_sync.py push --replace
```

## 4) 실시간에 가까운 자동 동기화
```powershell
cd C:\Users\mine8\Desktop\codex-pms\haewadal_pms
python supabase_sync.py watch --interval 3 --replace
```

또는 PC PMS 실행 자체를 Supabase 자동동기화 모드로 시작:

```powershell
cd C:\Users\mine8\Desktop\codex-pms
start_pms_with_supabase.bat
```

위 배치 파일은 PMS 실행 시 내부 `DatabaseManager`에서 autosync 스레드를 자동 시작합니다.

## 5) 복구/다운로드 (Supabase -> 로컬)
```powershell
cd C:\Users\mine8\Desktop\codex-pms\haewadal_pms
python supabase_sync.py pull
```

## 6) 권장 운영 방식
- 메인 PC: PMS 실행 + `supabase_sync.py watch` 실행
- 보조 PC/모바일: `realtime_server.py` 또는 모바일 앱으로 접속
- 장애 시: Supabase 데이터로 메인 PC 로컬 DB 복구(`pull`)

## 7) 주의사항
- `service_role` 키는 서버 PC에만 저장하세요.
- 여러 PC에서 동시에 `watch --replace`를 돌리면 충돌할 수 있습니다.
- 동시 양방향 편집이 필요하면 차후 완전한 Postgres 직접연동 버전으로 전환해야 합니다.

## 8) 동기화 모드 요약
- **권장**: 메인 PC 1대만 쓰기 + Supabase 동기화 + 다른 PC/모바일은 조회/업무 처리
- 고급: 여러 PC 쓰기 사용 시 운영 규칙(담당 객실 분리 등)을 정하고 사용
