@echo off
setlocal
set "SUPABASE_SYNC_MODE=pull"
call "%~dp0start_pms_with_supabase.bat"
endlocal

