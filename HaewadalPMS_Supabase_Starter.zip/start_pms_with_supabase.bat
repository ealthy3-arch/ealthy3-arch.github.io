@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "APP_EXE="
set "SOURCE_ROOT="
set "PYTHON_CMD="

set "CONFIG_DIR=%APPDATA%\HaewadalPMS"
if not exist "%CONFIG_DIR%" mkdir "%CONFIG_DIR%" >nul 2>&1
set "ENV_FILE=%CONFIG_DIR%\.env.supabase.local.cmd"

if exist "%SCRIPT_DIR%HaewadalPMS.exe" set "APP_EXE=%SCRIPT_DIR%HaewadalPMS.exe"
if "%APP_EXE%"=="" if exist "%ProgramFiles%\HaewadalPMS\HaewadalPMS.exe" set "APP_EXE=%ProgramFiles%\HaewadalPMS\HaewadalPMS.exe"
if "%APP_EXE%"=="" if defined ProgramFiles(x86) if exist "%ProgramFiles(x86)%\HaewadalPMS\HaewadalPMS.exe" set "APP_EXE=%ProgramFiles(x86)%\HaewadalPMS\HaewadalPMS.exe"
if "%APP_EXE%"=="" if exist "%LocalAppData%\Programs\HaewadalPMS\HaewadalPMS.exe" set "APP_EXE=%LocalAppData%\Programs\HaewadalPMS\HaewadalPMS.exe"

if exist "%SCRIPT_DIR%haewadal_motel_pms_v6.py" set "SOURCE_ROOT=%SCRIPT_DIR%"
if "%SOURCE_ROOT%"=="" if exist "%USERPROFILE%\Desktop\codex-pms\haewadal_motel_pms_v6.py" set "SOURCE_ROOT=%USERPROFILE%\Desktop\codex-pms\"

if exist "%ENV_FILE%" call "%ENV_FILE%"

if "%SUPABASE_URL%"=="" (
  set /p SUPABASE_URL=SUPABASE_URL (example: https://YOUR_PROJECT.supabase.co^) : 
)

if "%SUPABASE_SERVICE_ROLE_KEY%"=="" (
  set /p SUPABASE_SERVICE_ROLE_KEY=SUPABASE_SERVICE_ROLE_KEY : 
)

if "%SUPABASE_SYNC_MODE%"=="" set "SUPABASE_SYNC_MODE=push"
if /I "%SUPABASE_SYNC_MODE%"=="primary" set "SUPABASE_SYNC_MODE=push"
if /I "%SUPABASE_SYNC_MODE%"=="secondary" set "SUPABASE_SYNC_MODE=pull"
if /I "%SUPABASE_SYNC_MODE%"=="viewer" set "SUPABASE_SYNC_MODE=pull"
if /I not "%SUPABASE_SYNC_MODE%"=="push" if /I not "%SUPABASE_SYNC_MODE%"=="pull" (
  set /p SUPABASE_SYNC_MODE=SUPABASE_SYNC_MODE (push=main PC, pull=follower PC^) [push] : 
  if "%SUPABASE_SYNC_MODE%"=="" set "SUPABASE_SYNC_MODE=push"
)
if /I not "%SUPABASE_SYNC_MODE%"=="push" if /I not "%SUPABASE_SYNC_MODE%"=="pull" (
  set "SUPABASE_SYNC_MODE=push"
)

if "%SUPABASE_URL%"=="" (
  echo [ERROR] SUPABASE_URL is empty.
  pause
  exit /b 1
)

if "%SUPABASE_SERVICE_ROLE_KEY%"=="" (
  echo [ERROR] SUPABASE_SERVICE_ROLE_KEY is empty.
  pause
  exit /b 1
)

if "%SUPABASE_SYNC_INTERVAL_SEC%"=="" set "SUPABASE_SYNC_INTERVAL_SEC=3"
if "%SUPABASE_SYNC_REPLACE%"=="" set "SUPABASE_SYNC_REPLACE=1"

(
  echo @echo off
  echo set "SUPABASE_URL=%SUPABASE_URL%"
  echo set "SUPABASE_SERVICE_ROLE_KEY=%SUPABASE_SERVICE_ROLE_KEY%"
  echo set "SUPABASE_SYNC_MODE=%SUPABASE_SYNC_MODE%"
  echo set "SUPABASE_SYNC_INTERVAL_SEC=%SUPABASE_SYNC_INTERVAL_SEC%"
  echo set "SUPABASE_SYNC_REPLACE=%SUPABASE_SYNC_REPLACE%"
) > "%ENV_FILE%" 2>nul

if errorlevel 1 (
  echo [WARN] Could not save local config file: %ENV_FILE%
)

echo [Haewadal PMS] Supabase direct-sync mode starting...
echo [INFO] Sync mode: %SUPABASE_SYNC_MODE%

if not "%APP_EXE%"=="" (
  echo [INFO] Launching EXE: %APP_EXE%
  start "" "%APP_EXE%"
  exit /b 0
)

if "%SOURCE_ROOT%"=="" (
  echo [ERROR] Could not find HaewadalPMS.exe or source file haewadal_motel_pms_v6.py.
  echo         Install setup.exe first, or place this file next to codex-pms source.
  pause
  exit /b 1
)

where python >nul 2>&1 && set "PYTHON_CMD=python"
if "%PYTHON_CMD%"=="" where py >nul 2>&1 && set "PYTHON_CMD=py -3"

if "%PYTHON_CMD%"=="" (
  echo [ERROR] Python runtime not found. Install Python or use setup.exe installer build.
  pause
  exit /b 1
)

cd /d "%SOURCE_ROOT%"
echo [INFO] Source root: %SOURCE_ROOT%
if "%PYTHON_CMD%"=="python" (
  python haewadal_motel_pms_v6.py
) else (
  py -3 haewadal_motel_pms_v6.py
)

if errorlevel 1 (
  echo [ERROR] Failed to start PMS.
  pause
)

endlocal
